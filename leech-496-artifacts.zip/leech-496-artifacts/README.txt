==============================================================================
leech-496-artifacts
496 minimal vectors of the Leech lattice with no two at 60 degrees:
the record set, 64 maximal sets of the same size, and an exact
dual certificate of the upper bound |S| <= 837.
==============================================================================

Everything in this archive is checked by the single script verify.py, which
needs nothing but Python 3 (>= 3.8) and numpy.  No network access, no other
data files, no compiled code, no other Python package.  Unpack the archive,
cd into it, and run

    python3 verify.py --all

which runs every check below and prints one RESULT line.


1. COORDINATE CONVENTION
------------------------

The Leech lattice is realised in Z^24 in the integer scaling in which every
minimal vector has squared norm 32.  There are 196560 of them, of three
shapes:

    (+-2^8, 0^16)   supported on an octad of the extended binary Golay code,
                    with an even number of minus signs      759 * 128 = 97152
    (-+3, +-1^23)   a single entry +-3, signs flipped on a
                    Golay codeword                          24 * 4096 = 98304
    (+-4, +-4, 0^22)                                       4 * C(24,2) = 1104

Inner products between minimal vectors are integers in
{-32, -16, -8, 0, 8, 16, 32}.  Since every vector has squared norm 32, the
cosine of the angle between two of them is (inner product)/32, so

    two vectors subtend exactly 60 degrees  <=>  their inner product is 16.

A set of minimal vectors with no pair at inner product 16 therefore gives, after
normalisation, a set of unit vectors with pairwise angles > 60 degrees off the
antipodal pairs -- the objects that control the kissing number of the next
dimension up.  All set files in this archive are 60-degree-free in this sense.

verify.py regenerates the Golay code from the generator polynomial
g(x) = x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1 of the cyclic (23,12,7) code,
extends it by an overall parity bit, checks that the resulting code has 4096
words with weight distribution 1, 759, 2576, 759, 1 in weights 0, 8, 12, 16, 24
(which characterises the extended binary Golay code), then builds the 196560
vectors from the three shapes above and sorts them lexicographically ascending
with coordinate 0 most significant.  That order is the canonical order used
throughout.  Nothing in this archive depends on a stored copy of the lattice.


2. FILES
--------

        bytes  sha256                                                             file
        38014  6a68448a28650cefdc136bb6d5f7042e25c1d45b0e5dca8382ff681e8913c00a  verify.py
        28860  124da421631195969b27ab756774694f7e3f026625fed9449d906698d954ba70  S496.txt
       294217  47b4e0580caaa9a04b18c29165122b175a0cd211a076d927fc9654102069a8c3  sdp3_certificate.json
        11022  ddb901420b483b610590b21eb55309c1b18e3e9562d186e888b407def3803d65  scheme_orbitals.json
        29188  75899def2dc3a8e978862a8750ba6f4daf1c56779f2969315e91d66d32e42c70  plateau/S_00.txt
        29316  c95a8af2667c3cbdc28ba1c427f50590fb77b672865c4a233318b9d292a1057a  plateau/S_01.txt
        29316  05f1ead189c93ff72a2f7045d96ed02929ee0136901638aef5a056fe36e985c1  plateau/S_02.txt
        29323  fc07f564ec38c72ade845d770aa6fc9f538c37cc2610a69009f3d95eb77ee30b  plateau/S_03.txt
        29316  f51b7022b03004c266ee481660f3d941d2eb1fd8b8407d911b3024ce9ae62c99  plateau/S_04.txt
        29323  8c5c8c07333153f06a334a42fd6ed8108d5e08e638e6acd36442d6bfe4f657d0  plateau/S_05.txt
        29323  cafd6e095f77a61279ecdc0a5af2bd84dfba7dba14e5e275ae89d9a4f0fa1a26  plateau/S_06.txt
        29330  63d88d2b01e606ee275d8362e53fa0ada2eb5e995ce57679b98056f4fc93842b  plateau/S_07.txt
        29316  8fce162de163720e58ffe8b7a9400b3e95848b80f7708eee4708be125f973a38  plateau/S_08.txt
        29323  3839b1668899b1a2ffbc9d1890b8ba5411781ec06033d6746243d09e8334ae8f  plateau/S_09.txt
        29323  4c3c007b01ec41ce4cd33ed7206085c4b4f6f7a5f1ff94dcfeeedc8c213afb57  plateau/S_10.txt
        29330  33513fbc46a65c3caeef2e8d258e772c38dfcf41274153e2e7e2ad51a29bf8dc  plateau/S_11.txt
        29323  139ed70bb7ec5236049c0ad8d18c73b9a16520943ea57d433daf184fa6519b3c  plateau/S_12.txt
        29330  a2d39fc5632e1a9fce93e32e5602346d7a7b8f5b69bf8385a78c8b92b9bacea8  plateau/S_13.txt
        29330  19dbd9059d180116db18ce688394cc49ae811896cd1db9e5b47c3ee401fb7fe0  plateau/S_14.txt
        29339  bebbeaee6eb6f4bdac29094a78a4c1bb4de9dab389b524aeb780f135513a43a1  plateau/S_15.txt
        29188  f7fe3285437da857e5e87044b50e2ed114e1c3b9f254f8dcae5725d8889ea642  plateau/S_16.txt
        29195  8ef4da1d155a4be564784de2132cd570fe83c5132bd70985ccea3e3d77aa233f  plateau/S_17.txt
        29195  6623d3736ba6bb3cab24c3a9afd038328d98af3094cfb176d7a1756e244a2247  plateau/S_18.txt
        29204  c41976dd75221fe4d2e601d9fbb8034141a83c0faa1a718b713d6291916a19a7  plateau/S_19.txt
        29195  76c891a95f34f4eed668e9bcd9074b3df61c5e59fdb3db094dc79270ff169692  plateau/S_20.txt
        29204  b48c6d822eee1566e09aca769c8274c260d272616679dd15bfe584ecf4f9b382  plateau/S_21.txt
        29204  74dcdf7887782c1a79f5124c99a53aa307d14ceb34d5b13a0d9d1720b7563c2c  plateau/S_22.txt
        29213  55f0216b6c13acc990a202f5ab832dbd8b4413cce13c5d9ea0be8035fda4b148  plateau/S_23.txt
        29195  230462e1d17487fa8f0b374a9a5dcb15fcfa836d3169b17bf9f9b4489ec40b43  plateau/S_24.txt
        29204  3924401b419fc72c033bf6e857e96180132f128f00a9c6d3a8c2b1266089f9c0  plateau/S_25.txt
        29204  9cc2d322b2f97e9cfc7a0d475e6f762c81a35ac5db23328e8369aa9cfb04cd61  plateau/S_26.txt
        29213  8685fd222340a1a1c28c7bb3ca75f8d36e7d5d8a331002279321884b7f57a49f  plateau/S_27.txt
        29204  a01ec1c25ad60fdf4d1f36835dba8eee82726c23c476f2aaa3ff5640af744e2c  plateau/S_28.txt
        29213  67480e2b0fcc84125795a3a18e93e05d02f1d98fcb03e8ba09ce02fba89916de  plateau/S_29.txt
        29213  6341cc07e6e15c83665110b1a10856f6d9d6d3bef61de7124d70c1d72f135018  plateau/S_30.txt
        29220  bba055193801969714ccd4353622a44fbc6ac376702484ab9110231b1da07052  plateau/S_31.txt
        29444  f213bd6057c256a297a8c8bd5c826a0186cb9fe2a77ddd4b2d8c2617b23dabb3  plateau/S_32.txt
        29451  51d9b0493df78c463bc5dc58a3236c763e5e6633660404fe404013aca1eadb7a  plateau/S_33.txt
        29451  6bb4f64255530c80a3e1ac28d45b6ff16aee31dc3a6de148a3d95be0be990f71  plateau/S_34.txt
        29460  217de2d62a78010620b773772425f02fba3351a6c79d5518fc01be7318771414  plateau/S_35.txt
        29451  2a4e05c89e8eec7149eb22f4997e81490a2237df4d1038a2902d9e6d654f765c  plateau/S_36.txt
        29460  2cd35099b36b06fa5c485148d3de0aed00f48c13b9de451979ba1e33c2b8c770  plateau/S_37.txt
        29460  1d8b83896e55c2a83ab525b2c6a42ca494ad83ddf45328bacd368eed6eaf27e9  plateau/S_38.txt
        29469  bb19c41cb1b113d0904b403d97d107179027338562e6f6bee3445493dcc50a94  plateau/S_39.txt
        29451  6b4cfd305fdc59925ceba180458f668f82cbc5660c823bb16afb38a98cd906b5  plateau/S_40.txt
        29460  42e47f033696a2b1dd2ef237e43a870ba1f9cc0a7a5819a272f1ea9bd0395749  plateau/S_41.txt
        29460  3b28fd52ad9f2df82a15b97d51da5e784c6c9b2e91c1006e4d32e9f42009011e  plateau/S_42.txt
        29469  e208785e05ba7da57cd2e1854d3c84af5c8eec19d7f83f3b640e49c64089e194  plateau/S_43.txt
        29460  f8ec0298b0f2be5dbc559e14505764b314f8d16cf30ecfa8bc8404a5d7d86137  plateau/S_44.txt
        29469  e908af4d57b90d3a0f16a7060c1097e5b9d29864c204751a234a5c569b490b3f  plateau/S_45.txt
        29469  6b63b718508ac96b70ad059787076a1a222a699d0097f994bd621f5723c7eac1  plateau/S_46.txt
        29476  f387f2ebca2a0aea51b1364f69de5515cf87c50e2273a9c87b00de1af611518d  plateau/S_47.txt
        29325  a048d1dbdd9b7e2bdc05f891327505fadd9b5569e6f41ee9d441a2bbf4fb9d4f  plateau/S_48.txt
        29332  8dec21ee66db81d4a68ba9aab8e50f6241d40f0e94914452a6d5fa33d5c3073a  plateau/S_49.txt
        29332  998dfdc38e824541d18af6c1d8fad0b9729de54e9cdee2032faab67598b99093  plateau/S_50.txt
        29341  4483a961fd585bb5631ba7ff73aacd3d4451b77807b0e8d447ad803f45725909  plateau/S_51.txt
        29332  2f229d3e740992dfc031702fe6ce015b9cc2a534b0134ab1965786c7579adf2f  plateau/S_52.txt
        29341  b70cd8733bf4f4d7d81c526f2c5ad466fb4205d449f81465f8d5307c7f448a08  plateau/S_53.txt
        29341  5d105da004b0ab8d9f8eeb4c8b61b84c9a17e16f26d1b438fc3c57caf05ec6d4  plateau/S_54.txt
        29348  e2aae3d323162a9063dfa83f59baaa38b37872097686cb8f0738ed3c249eeb4c  plateau/S_55.txt
        29332  7585f4ff5a39590d170311af7e8193fb50ca5c7b0538331a735333b37b8d7472  plateau/S_56.txt
        29341  4219e2250bf7aa92c8b164fc041bf4ec5cdd982db48a2d0897d443bc0d099da1  plateau/S_57.txt
        29341  9ff1ffb908714f4fbd138d65f2a98fa76dbe34cebe69f6b10c35f8f8cb6841be  plateau/S_58.txt
        29348  ebc2a16430c8c656baddcb425093ece025c892b899cdf42c981d5367d37ce569  plateau/S_59.txt
        29341  04fd7452410d59dab370863c043946400ae96a33516e0563f89be0f65781e1cb  plateau/S_60.txt
        29348  577da5aff78bec3b279f6e420a1f4ec609f3e59c4ddb4b2f5547f923da887830  plateau/S_61.txt
        29348  c40c1db73819b96ed7200793abe09946a3a9b2957fc6cb53bcde5311b40c6c8a  plateau/S_62.txt
        29355  ee56722dd88c14486998914740afb740395723ea4c6d622d320aaca5d1dd3e5b  plateau/S_63.txt

(README.txt itself is not listed -- it cannot contain its own hash.)

Integrity of the unpacked archive can be checked with, e.g.

    sha256sum verify.py S496.txt sdp3_certificate.json scheme_orbitals.json \
              plateau/S_*.txt

but the sha256 values are only a transport check.  The mathematical content of
every file is checked by verify.py, as described next.


3. WHAT EACH FILE IS, AND THE EXACT COMMAND THAT CHECKS IT
---------------------------------------------------------

S496.txt
    496 lines of 24 integers: the record 496-element 60-degree-free set of
    Leech minimal vectors.  Row order is the source order of the configuration
    it came from (see section 5).

        python3 verify.py --set S496.txt

    proves: every row is one of the 196560 minimal vectors regenerated from
    scratch; the 496 rows are distinct; no ordered pair has inner product 16,
    i.e. no two of the 496 directions are at 60 degrees; the set is antipodal
    (S = -S); and -- the maximality sweep -- for every one of the 196560
    minimal vectors v the number t(v) of members of S at inner product 16 is
    computed.  A vector outside S with t(v) = 0 could be adjoined, so S is
    maximal exactly when no such free vertex exists.  Runtime about 2 seconds.
    Add --no-maximality to skip the sweep (then about 0.3 seconds).

plateau/S_00.txt ... plateau/S_63.txt
    64 further 496-element 60-degree-free sets, all maximal.  S_00 is the
    record set S496.txt again (same set, rows sorted).  The other 63 are
    obtained from it by the six commuting plateau moves described in the header
    of every file: six pairs (R_i, A_i) of equal-size sets of minimal vectors,
    R_i inside S and A_i outside it, of sizes 12, 12, 12, 12, 80, 80, with all
    twelve sets pairwise disjoint and each closed under negation.  For a subset
    T of {0,...,5},

        S_T = (S \ union_{i in T} R_i)  u  (union_{i in T} A_i)

    is again a 496-element 60-degree-free set, and the 64 subsets T give 64
    distinct such sets.  The moves themselves can be read straight off this
    archive: R_i = S_00 \ S_{2^i} and A_i = S_{2^i} \ S_00.

        python3 verify.py --set plateau/S_07.txt

    runs the same checks as for S496.txt on one file.  Runtime about 2 seconds
    per file.

sdp3_certificate.json
    An exact rational dual certificate for the three-point (Schrijver /
    Terwilliger style) semidefinite relaxation of the problem "how large can a
    60-degree-free set of Leech minimal vectors be?".  It contains: the two
    positive semidefinite multipliers Y1, Y2, each written as a sum of rank-one
    terms m_i p_i p_i^T / 2^e with integer p_i and integer m_i >= 0 (so they
    are PSD by construction and no numerical eigenvalue test is ever needed);
    the nonnegative rational multipliers mu and rho; and the resulting
    per-variable values h_q and the bound.

        python3 verify.py --certificate sdp3_certificate.json

    proves: |S| <= 837 for every 60-degree-free set S of Leech minimal vectors.
    Runtime about 10 seconds.  See section 4 for exactly how self-contained
    this check is.

scheme_orbitals.json
    A numbering: it assigns the labels 0..147 to the 148 orbitals of a point
    stabiliser of the Leech minimal-vector scheme (equivalently, to the orbits
    of the automorphism group on ordered triples of minimal vectors).  The
    matrices inside sdp3_certificate.json are written in this labelling, so the
    labelling has to be shipped with it.  Nothing else is taken from this file:
    every quantity it records -- the class pattern (i,j,k) of each orbital, the
    orbit sizes, and the two involutions induced by the symmetric group on
    three points -- is recomputed by verify.py from the regenerated 196560
    vectors and compared entry by entry.  It is checked as part of

        python3 verify.py --certificate sdp3_certificate.json

verify.py
    The verifier.  Reading it is the point; it is written to be read.

        python3 verify.py --all

    runs everything: the lattice regeneration, all 65 set files with their
    maximality sweeps, and the certificate.  Runtime about 100 seconds and
    under 400 MB of peak memory.  It ends with a single line

        RESULT ok=1 golay_words=4096 leech_vectors=196560 sets_checked=65 ...

    Any failed check raises, prints FAILED and a RESULT ok=0 line, and exits
    with status 1.


4. WHAT THE CERTIFICATE CHECK ACTUALLY DOES
-------------------------------------------

This is the part where "self-contained" is easy to claim and hard to mean, so
here is precisely what happens.

The 196560 minimal vectors carry a 7-class association scheme (the classes are
the seven inner products).  The relaxation is built inside the centraliser
algebra of a point stabiliser, which is spanned by the 148 orbitals; the
certificate's coefficient matrices are contractions of that algebra's structure
constants c[u,s,t].  verify.py recomputes all of that from the lattice:

  * the seven valencies 1, 4600, 47104, 93150, 47104, 4600, 1, from the inner
    products of every minimal vector with a base point (and again with a base
    point of a different shape);
  * the intersection numbers p^i_jk of the scheme, from one base pair per
    class -- 7 sweeps over all 196560 vectors;
  * the fact that exactly 147 of the 343 cells (i,j,k) are non-empty, and that
    exactly one of them, the cell of mutually orthogonal triples, carries two
    orbitals rather than one.  The two are separated by the invariant

        n(x,y,z) = #{v minimal : <v,x> = <v,y> = <v,z> = 16},

    which is measured to take the value 0 on 42240 vectors and the value 2 on
    924 of the 43164 vectors orthogonal to both x and y.  This is measured for
    every base pair used, never assumed;
  * the transpose and swap involutions on the 148 orbitals;
  * the full tensor of structure constants c[u,s,t], from one base pair per
    orbital: 148 sweeps over all 196560 vectors, in exact integer arithmetic.

The recomputed tensor is then put through exact checks that pin down that it is
the structure-constant tensor of a matrix *-algebra: prescribed support, row
and column sums, the identity |u| c^u_st = |s| c^s_{u t^T}, the fact that the
seven diagonal orbitals sum to the unit, and full associativity (the
associativity check runs in float64, which is exact here because every partial
sum is an integer below 2^53; verify.py checks that bound before relying on it).

Only then is the certificate read.  Its own structural fields are re-derived
and compared: the objective vector, the matrix Cy, the partition of the 148
orbitals into the 43 unordered-triple variables, the index of the variable
pinned to 1, and the list of free variables implied by forbidding the inner
product 16.  The two multipliers are confirmed to be sums of rank-one terms
with nonnegative integer weights, hence positive semidefinite by construction.
Then

    h_q = objective_q + <Y1, G_q> + <Y2, Gy_q> + (mu^T Cy)_q - rho_q

is recomputed for all 43 variables in exact rational arithmetic (Python's
Fraction), compared against the stored values, and the bound

    h_e + sum_{q free} rho_q + sum_{q free, q != e} max(0, h_q)

is formed and its floor taken.  The result is 837.  Because every step is an
exact rational inequality, the bound is rigorous no matter how good or bad the
numerical solver that produced the multipliers was: a poor dual solution makes
the bound weaker, never wrong.  The solver is not present in this archive and
nothing here depends on it.

The only thing verify.py takes on faith from disk is the labelling 0..147 in
scheme_orbitals.json -- a numbering convention, without which the certificate's
matrices could not be interpreted at all -- and every mathematical field of
that file is re-derived and compared.  There is no held-back step: the whole
chain from the Golay generator polynomial to the number 837 runs inside this
archive.


5. PROVENANCE AND CREDIT
------------------------

The 496-point configuration in S496.txt is due to

    C. Ma, T. T. Zhaowei, P. Li, M. Liu, H. Chen, Z. Mao, B. Li, Y. Cheng,
    Y. Qi, Y. Yang, "Finding kissing numbers with game-theoretic reinforcement
    learning", arXiv:2511.13391 (2025); data at
    https://github.com/CDM1619/PackingStar

It appears here re-expressed in the coordinate convention of section 1.  As a
subset of the 196560 minimal vectors it is theirs and unchanged; only the
coordinate realisation of the lattice differs (by a permutation of the 24
coordinates).  The 63 further sets in plateau/ are obtained from it by the six
moves described in section 3.


6. WHAT IS NOT IN THIS ARCHIVE
------------------------------

  * No proof that the 64 sets in plateau/ are pairwise inequivalent under the
    automorphism group of the Leech lattice.  verify.py checks that they are
    pairwise distinct as sets and reports each one's tightness histogram; among
    the 64 there are 5 distinct such histograms, so that invariant alone
    separates the 64 into only 5 groups.  Any stronger inequivalence statement
    is not established here.
  * No group theory at all: the automorphism group of the Leech lattice is
    never constructed.  verify.py uses only the 196560 vectors and integer
    arithmetic on them.
  * No search code.  How the plateau moves were found is not part of this
    archive; the archive only certifies the resulting sets.
  * No derivation of the certificate.  The semidefinite program and the
    numerical solve that produced Y1, Y2, mu and rho are not included -- only
    the resulting exact certificate and its independent re-check.  As explained
    in section 4, the validity of the bound does not depend on them.
  * No claim that 496 is optimal.  What is proved here is 496 <= max <= 837,
    together with the maximality of the 65 particular sets.  The gap is open.
  * No configurations in other dimensions, and no kissing-number configuration
    is constructed from these sets here; the sets are the input to such a
    construction, not the output.

