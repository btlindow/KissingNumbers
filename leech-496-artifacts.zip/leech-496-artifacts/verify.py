#!/usr/bin/env python3
"""Standalone verifier for the 496-point 60-degree-free sets of Leech minimal
vectors and for the exact dual certificate of the three-point bound |S| <= 837.

Requirements: Python 3.8+ and numpy.  Nothing else: no network, no other data
files beyond the ones shipped next to this script.

What it does
------------
(a)  Regenerates the extended binary Golay code G24 and all 196560 minimal
     vectors of the Leech lattice from scratch, and checks them.
(b)  Checks a set file: every row is a Leech minimal vector, all rows distinct,
     no pair at inner product 16 (equivalently, no two directions at 60
     degrees); reports |S|, the Gram off-diagonal histogram and whether the set
     is antipodal (S = -S).
(c)  Checks maximality: for every one of the 196560 minimal vectors v it counts
     tightness t(v) = #{s in S : <v,s> = 16}.  A vector outside S with t(v) = 0
     could be added to S, so S is maximal exactly when there is no such "free"
     vertex.  Reports the number of free vertices, the minimum tightness
     outside S and the full tightness histogram.
(d)  Re-verifies the dual certificate of the three-point semidefinite bound
     |S| <= 837 in exact rational arithmetic.  The 7-class association scheme
     of the Leech minimal vectors, its 148-dimensional Terwilliger-type
     centraliser algebra and all of that algebra's structure constants are
     RECOMPUTED here from the freshly generated 196560 vectors; the only thing
     read from disk is scheme_orbitals.json, which fixes the *numbering*
     0..147 of the 148 orbitals that the certificate's matrices are written
     in.  Every field of that file (class pattern, orbit sizes, transpose and
     swap involutions) is re-derived from the lattice and compared.
(e)  --all runs (a)-(d) over every set shipped in this archive and prints one
     RESULT line.

Coordinate convention
---------------------
The Leech lattice is realised in Z^24 in the integer scaling in which every
minimal vector has squared norm 32.  Inner products of minimal vectors are then
integers in {-32,-16,-8,0,8,16,32}; the inner product 16 corresponds to
cos(theta) = 16/32 = 1/2, i.e. an angle of exactly 60 degrees.

Usage
-----
    python3 verify.py --all
    python3 verify.py --lattice
    python3 verify.py --set S496.txt
    python3 verify.py --set plateau/S_00.txt --no-maximality
    python3 verify.py --certificate sdp3_certificate.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from fractions import Fraction
from itertools import combinations

import numpy as np

DIM = 24
N_MIN = 196560
DOTS = (-32, -16, -8, 0, 8, 16, 32)
CONFLICT_DOT = 16          # 60 degrees
CONFLICT_CLASS = 5         # index of 16 in DOTS
IDENTITY_CLASS = 6         # index of 32 in DOTS
NCLASS = 7
EXPECTED_VALENCIES = (1, 4600, 47104, 93150, 47104, 4600, 1)
EXPECTED_GOLAY_WEIGHTS = {0: 1, 8: 759, 12: 2576, 16: 759, 24: 1}

HERE = os.path.dirname(os.path.abspath(__file__)) or "."


class CheckError(Exception):
    pass


def need(cond, msg):
    if not cond:
        raise CheckError(msg)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------
# (a) the extended binary Golay code G24
# --------------------------------------------------------------------------

# g(x) = x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1, a generator polynomial of the
# cyclic binary Golay code of length 23.  Bit i of a mask is the coefficient of
# x^i; coordinate 23 carries the overall parity bit of the extension.
GOLAY_GENERATOR = (1 << 11) | (1 << 10) | (1 << 6) | (1 << 5) | (1 << 4) | (1 << 2) | 1


def _clmul(a, b):
    """Product of two GF(2)[x] polynomials given as bit masks."""
    out = 0
    while b:
        if b & 1:
            out ^= a
        a <<= 1
        b >>= 1
    return out


def golay_codewords():
    """The 4096 codewords of G24 as 24-bit masks, ascending."""
    words = []
    for m in range(1 << 12):
        c = _clmul(m, GOLAY_GENERATOR)          # degree <= 22, no reduction needed
        if c >> 23:
            raise CheckError("generator polynomial product overflowed 23 bits")
        c |= (bin(c).count("1") & 1) << 23      # overall parity
        words.append(c)
    words.sort()
    return words


def check_golay(words, log):
    need(len(words) == 4096, "G24 must have 4096 codewords")
    need(len(set(words)) == 4096, "G24 codewords are not distinct")
    dist = {}
    for w in words:
        k = bin(w).count("1")
        dist[k] = dist.get(k, 0) + 1
    need(dist == EXPECTED_GOLAY_WEIGHTS,
         "weight distribution of G24 is %r, expected %r" % (dist, EXPECTED_GOLAY_WEIGHTS))
    # linearity: closed under XOR (checked on a random-free deterministic sample
    # plus the full check that the code is the span of 12 basis words)
    ws = set(words)
    basis = [_clmul(1 << i, GOLAY_GENERATOR) for i in range(12)]
    basis = [b | ((bin(b).count("1") & 1) << 23) for b in basis]
    span = {0}
    for b in basis:
        span |= {s ^ b for s in span}
    need(span == ws, "G24 is not the span of the 12 shifts of g(x)")
    for a in words[::64]:
        for b in words[::128]:
            need((a ^ b) in ws, "G24 is not closed under XOR")
    log("  Golay code G24: 4096 codewords, weight distribution "
        + ", ".join("%d:%d" % kv for kv in sorted(dist.items()))
        + "; minimum distance 8; linear (span of 12 shifts of g(x)): OK")
    return dist


# --------------------------------------------------------------------------
# (a) the 196560 minimal vectors
# --------------------------------------------------------------------------

def leech_minimal_vectors(words):
    """All 196560 minimal vectors, int8 (196560, 24), sorted lexicographically
    ascending with coordinate 0 most significant (the canonical order used by
    every index in this archive).

    Three shapes, in the squared-norm-32 scaling:
      (+-2^8, 0^16)  supported on an octad, an even number of minus signs
                                                        759 * 128  = 97152
      (-+3, +-1^23)  a single +-3, signs flipped on a Golay codeword
                                                        24 * 4096  = 98304
      (+-4, +-4, 0^22)                                  4 * C(24,2)=  1104
    """
    octads = [w for w in words if bin(w).count("1") == 8]
    if len(octads) != 759:
        raise CheckError("expected 759 octads, got %d" % len(octads))

    pats = np.array([[(s >> j) & 1 for j in range(8)] for s in range(256)], dtype=np.int8)
    even = pats[pats.sum(axis=1) % 2 == 0]
    signs = ((1 - 2 * even) * 2).astype(np.int8)        # +-2, 128 patterns
    A = np.zeros((759 * 128, DIM), dtype=np.int8)
    r = 0
    for o in octads:
        idx = [i for i in range(DIM) if (o >> i) & 1]
        A[r:r + 128, idx] = signs
        r += 128

    flip = np.array([[-1 if (c >> j) & 1 else 1 for j in range(DIM)] for c in words],
                    dtype=np.int8)
    B = np.empty((DIM * len(words), DIM), dtype=np.int8)
    for i in range(DIM):
        base = np.ones(DIM, dtype=np.int8)
        base[i] = -3
        B[i * len(words):(i + 1) * len(words)] = base[None, :] * flip

    C = np.zeros((1104, DIM), dtype=np.int8)
    r = 0
    for i, j in combinations(range(DIM), 2):
        for si in (4, -4):
            for sj in (4, -4):
                C[r, i] = si
                C[r, j] = sj
                r += 1

    V = np.concatenate([A, B, C], axis=0)
    return V[np.lexsort(V.T[::-1])]


def check_lattice(V, log):
    need(V.shape == (N_MIN, DIM), "expected %d x %d, got %r" % (N_MIN, DIM, V.shape))
    W = V.astype(np.int64)
    norms = (W * W).sum(axis=1)
    need(int(norms.min()) == 32 and int(norms.max()) == 32,
         "not every vector has squared norm 32")
    keys = V.tobytes()
    rows = [keys[i * DIM:(i + 1) * DIM] for i in range(N_MIN)]
    index = {}
    for i, k in enumerate(rows):
        index[k] = i
    need(len(index) == N_MIN, "the %d generated vectors are not distinct" % N_MIN)
    # inner products with the first vector: the 7 classes and their valencies
    d0 = W @ W[0]
    need(set(np.unique(d0).tolist()) <= set(DOTS), "inner products outside {-32..32}")
    cls0 = np.searchsorted(np.array(DOTS), d0)
    val = tuple(int(x) for x in np.bincount(cls0, minlength=NCLASS))
    need(val == EXPECTED_VALENCIES,
         "valencies %r, expected %r" % (val, EXPECTED_VALENCIES))
    # a second base vector, of a different shape, must give the same valencies
    other = int(np.flatnonzero(np.abs(W).max(axis=1) == 4)[0])
    d1 = W @ W[other]
    need(set(np.unique(d1).tolist()) <= set(DOTS), "inner products outside {-32..32}")
    val1 = tuple(int(x) for x in np.bincount(np.searchsorted(np.array(DOTS), d1),
                                            minlength=NCLASS))
    need(val1 == EXPECTED_VALENCIES, "valencies from a second base point differ")
    # the set is symmetric under negation
    neg = np.array([index.get(bytes((-V[i]).astype(np.int8).tobytes()), -1)
                    for i in (0, 1, 2, N_MIN - 1)])
    need((neg >= 0).all(), "negation leaves the generated set")
    negidx = np.arange(N_MIN)[::-1]
    need(np.array_equal(V[negidx], -V.astype(np.int16)),
         "the canonical order is not reversed by negation")
    log("  Leech minimal vectors: %d rows, all of squared norm 32, all distinct;" % N_MIN)
    log("    inner products lie in {-32,-16,-8,0,8,16,32}; valencies from a base")
    log("    vector: " + ", ".join("%+d:%d" % (DOTS[i], val[i]) for i in range(NCLASS)))
    log("    the set is closed under negation (row i pairs with row %d-1-i)" % N_MIN)
    return index, cls0


# --------------------------------------------------------------------------
# (b) set files
# --------------------------------------------------------------------------

def read_set(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = line.split()
            need(len(parts) == DIM, "%s: a row has %d entries, expected %d"
                 % (os.path.basename(path), len(parts), DIM))
            rows.append([int(t) for t in parts])
    need(rows, "%s: no data rows" % path)
    return np.array(rows, dtype=np.int64)


def check_set(V, index, S, name, log):
    n = S.shape[0]
    norms = (S * S).sum(axis=1)
    need(int(norms.min()) == 32 and int(norms.max()) == 32,
         "%s: a row does not have squared norm 32" % name)
    idx = []
    for i in range(n):
        k = S[i].astype(np.int8).tobytes()
        j = index.get(k)
        need(j is not None, "%s: row %d is not a Leech minimal vector" % (name, i))
        idx.append(j)
    idx = np.array(idx, dtype=np.int64)
    need(len(set(idx.tolist())) == n, "%s: rows are not distinct" % name)

    G = S @ S.T
    off = G[~np.eye(n, dtype=bool)]
    vals, cts = np.unique(off, return_counts=True)
    hist = {int(v): int(c) for v, c in zip(vals, cts)}
    need(set(hist) <= set(DOTS), "%s: Gram entries outside the 7 classes" % name)
    conflicts = hist.get(CONFLICT_DOT, 0)
    need(conflicts == 0,
         "%s: %d ordered pairs at inner product 16 (60 degrees)" % (name, conflicts))

    negset = set((-S[i]).astype(np.int8).tobytes() for i in range(n))
    antipodal = negset == set(S[i].astype(np.int8).tobytes() for i in range(n))

    log("  %s: |S| = %d, all rows are Leech minimal vectors, all distinct" % (name, n))
    log("    Gram off-diagonal histogram over the %d ordered pairs: {%s}"
        % (n * (n - 1),
           ", ".join("%d: %d" % (d, hist[d]) for d in sorted(hist))))
    log("    pairs at inner product 16 (60 degrees): 0  ->  the set is 60-degree-free")
    log("    antipodal (S = -S): %s" % ("yes" if antipodal else "no"))
    fingerprint = hashlib.sha256(np.sort(idx).astype(np.int64).tobytes()).hexdigest()
    log("    set fingerprint (sha256 of the sorted canonical indices): %s" % fingerprint[:32])
    return {"n": n, "idx": idx, "gram": hist, "antipodal": antipodal,
            "fingerprint": fingerprint}


# --------------------------------------------------------------------------
# (c) maximality
# --------------------------------------------------------------------------

def tightness(V, S, chunk=32768):
    """t[v] = #{s in S : <v,s> = 16} for every one of the 196560 vectors v.

    float64 is exact here: every partial sum is an integer of magnitude <= 288.
    """
    Vf = V.astype(np.float64)
    Sf = np.ascontiguousarray(S.astype(np.float64).T)
    out = np.empty(V.shape[0], dtype=np.int32)
    for a in range(0, V.shape[0], chunk):
        b = min(a + chunk, V.shape[0])
        out[a:b] = (Vf[a:b] @ Sf == 16.0).sum(axis=1)
    return out


def check_maximality(V, S, idx, name, log, verbose=True):
    t = tightness(V, S)
    inside = np.zeros(V.shape[0], dtype=bool)
    inside[idx] = True
    need(int(t[inside].max()) == 0,
         "%s: a member of S has a 60-degree partner inside S" % name)
    outside = t[~inside]
    free = int((outside == 0).sum())
    tmin = int(outside.min())
    nmin = int((outside == tmin).sum())
    vals, cts = np.unique(outside, return_counts=True)
    hist = {int(v): int(c) for v, c in zip(vals, cts)}
    log("  %s: maximality sweep over all %d minimal vectors" % (name, V.shape[0]))
    log("    free vertices (outside S, tightness 0): %d  ->  S is %s"
        % (free, "MAXIMAL" if free == 0 else "NOT maximal"))
    log("    minimum tightness outside S: %d, attained by %d vectors" % (tmin, nmin))
    if verbose:
        log("    tightness histogram outside S: "
            + ", ".join("%d:%d" % (k, hist[k]) for k in sorted(hist)))
    return {"free": free, "min_tightness": tmin, "n_min": nmin, "hist": hist}


# --------------------------------------------------------------------------
# (d) the association scheme, its centraliser algebra, and the certificate
# --------------------------------------------------------------------------

class Scheme(object):
    """The 7-class association scheme of the Leech minimal vectors and the
    148-dimensional centraliser algebra of a point stabiliser, recomputed from
    the generated vectors.

    Orbitals: for the fixed base point x = V[0], the orbits of Stab(x) on
    ordered pairs (y,z), equivalently the orbits of the full automorphism group
    on ordered triples (x,y,z).  Each orbital lies in one "cell"
    (i,j,k) = (class(x,y), class(x,z), class(y,z)); 147 cells are non-empty and
    exactly one of them, the cell (3,3,3) of mutually orthogonal triples,
    carries two orbitals, of sizes 42240 and 924 per fixed y.  This is checked,
    not assumed.  The two are separated by the symmetric invariant

        n(x,y,z) = #{v minimal : <v,x> = <v,y> = <v,z> = 16},

    which takes the value 0 on the orbital of size 42240 and 2 on the one of
    size 924.

    Structure constants c[u,s,t] = #{w : (x,y,w) in orbital s and
    (x,w,z) in orbital t} for any (y,z) in orbital u.
    """

    def __init__(self, V, cls0, orbital_map, log):
        self.V = V
        self.N = V.shape[0]
        self.W = V.astype(np.int32)
        self.x = self.W[0]
        self.cls0 = cls0.astype(np.int64)
        self.dots = np.array(DOTS, dtype=np.int32)
        self.valencies = tuple(int(v) for v in np.bincount(self.cls0, minlength=NCLASS))

        # class representatives, chosen canonically: the first vector of each class
        self.reps = [int(np.flatnonzero(self.cls0 == i)[0]) for i in range(NCLASS)]

        # cell census p^i_{jk} = #{w : class(x,w)=j, class(y_i,w)=k}
        self.clsrep = np.empty((NCLASS, self.N), dtype=np.int64)
        for i in range(NCLASS):
            self.clsrep[i] = np.searchsorted(self.dots, self.W @ self.W[self.reps[i]])
        P = np.zeros((NCLASS, NCLASS, NCLASS), dtype=np.int64)
        for i in range(NCLASS):
            P[i] = np.bincount(self.cls0 * NCLASS + self.clsrep[i],
                               minlength=NCLASS * NCLASS).reshape(NCLASS, NCLASS)
        self.P = P
        ncells = int((P > 0).sum())
        need(ncells == 147, "expected 147 non-empty cells, got %d" % ncells)

        # the split of the cell (3,3,3), measured
        m333 = (self.cls0 == 3) & (self.clsrep[3] == 3)
        cnt = self._triple16(self.W[self.reps[3]], m333)
        vals, cts = np.unique(cnt, return_counts=True)
        need(len(vals) == 2 and sorted(int(c) for c in cts) == [924, 42240],
             "the cell (3,3,3) does not split as 924 + 42240 under the invariant n")
        log("  scheme: 7 classes with valencies %s" % (self.valencies,))
        log("    147 non-empty cells (i,j,k); the cell (3,3,3) of mutually orthogonal")
        log("      triples splits into two orbitals of sizes 42240 and 924 per fixed y")
        log("    -> D = 148 orbitals")

        # ---- the shipped numbering, validated entry by entry
        rows = orbital_map["orbitals"]
        D = self.D = len(rows)
        need(D == 148, "expected 148 orbitals in the numbering file, got %d" % D)
        need([r[0] for r in rows] == list(range(D)), "orbital ids are not 0..147")
        self.oi = np.array([r[1] for r in rows], dtype=np.int64)
        self.oj = np.array([r[2] for r in rows], dtype=np.int64)
        self.ok = np.array([r[3] for r in rows], dtype=np.int64)
        self.osize = np.array([r[4] for r in rows], dtype=np.int64)
        self.size = np.array([r[5] for r in rows], dtype=object)
        self.otr = np.array([r[6] for r in rows], dtype=np.int64)
        self.osw = np.array([r[7] for r in rows], dtype=np.int64)

        cellid = -np.ones((NCLASS, NCLASS, NCLASS), dtype=np.int64)
        split = {}
        for u in range(D):
            i, j, k = int(self.oi[u]), int(self.oj[u]), int(self.ok[u])
            need(P[i, j, k] > 0, "orbital %d claims the empty cell (%d,%d,%d)" % (u, i, j, k))
            if (i, j, k) == (3, 3, 3):
                split[int(self.osize[u])] = u
            else:
                need(cellid[i, j, k] == -1,
                     "cell (%d,%d,%d) carries more than one orbital" % (i, j, k))
                cellid[i, j, k] = u
        need(set(split) == {42240, 924},
             "the two orbitals of the cell (3,3,3) do not have sizes 42240 and 924")
        need(int((cellid >= 0).sum()) == 146, "the numbering does not cover 146 simple cells")
        self.cellid = cellid
        self.split_big, self.split_small = split[42240], split[924]
        # orbit sizes per cell must reproduce the measured cell census
        for i in range(NCLASS):
            for j in range(NCLASS):
                for k in range(NCLASS):
                    tot = int(self.osize[(self.oi == i) & (self.oj == j) & (self.ok == k)].sum())
                    need(tot == int(P[i, j, k]),
                         "cell (%d,%d,%d): orbit sizes sum to %d, the lattice gives %d"
                         % (i, j, k, tot, P[i, j, k]))
        for u in range(D):
            need(int(self.size[u]) == self.valencies[int(self.oi[u])] * int(self.osize[u]),
                 "orbital %d: |u| != v_i * (orbit size)" % u)
        log("    orbit sizes per cell reproduce the measured intersection numbers p^i_jk")

        # ---- transpose / swap involutions, re-derived
        tr = np.zeros(D, dtype=np.int64)
        sw = np.zeros(D, dtype=np.int64)
        for u in range(D):
            i, j, k = int(self.oi[u]), int(self.oj[u]), int(self.ok[u])
            # the invariant n is symmetric in x, y, z, so both S_3 generators fix
            # each of the two orbitals of the cell (3,3,3)
            tr[u] = u if (j, i, k) == (3, 3, 3) else int(cellid[j, i, k])
            sw[u] = u if (i, k, j) == (3, 3, 3) else int(cellid[i, k, j])
        need(np.array_equal(tr, self.otr), "the transpose map in the numbering file is wrong")
        need(np.array_equal(sw, self.osw), "the swap map in the numbering file is wrong")
        need(np.array_equal(tr[tr], np.arange(D)) and np.array_equal(sw[sw], np.arange(D)),
             "transpose / swap are not involutions")
        log("    transpose and swap involutions re-derived from the lattice: OK")

        # ---- labels, representatives, structure constants
        self.lab7 = [self._labels(self.W[self.reps[i]], i) for i in range(NCLASS)]
        zrep = np.zeros(D, dtype=np.int64)
        for u in range(D):
            hits = np.flatnonzero(self.lab7[int(self.oi[u])] == u)
            need(len(hits) == int(self.osize[u]),
                 "orbital %d: %d representatives found, %d expected"
                 % (u, len(hits), int(self.osize[u])))
            zrep[u] = hits[0]
        self.zrep = zrep

        c = np.zeros((D, D, D), dtype=np.int64)
        for u in range(D):
            s = self.lab7[int(self.oi[u])]
            t = tr[self._labels(self.W[zrep[u]], int(self.oj[u]))]
            c[u] = np.bincount(s * D + t, minlength=D * D).reshape(D, D)
        self.c = c
        log("    structure constants c[u,s,t] of the 148-dimensional algebra recomputed")
        log("      from the lattice (one base pair per orbital, %d sweeps of %d vectors)"
            % (D, self.N))

        # diagonal orbitals and the S_3 (unordered-triple) orbits
        self.dg = []
        for k in range(NCLASS):
            hit = [u for u in range(D)
                   if int(self.oi[u]) == k and int(self.oj[u]) == k
                   and int(self.ok[u]) == IDENTITY_CLASS and int(self.osize[u]) == 1]
            need(len(hit) == 1, "diagonal orbital of class %d not identified" % k)
            self.dg.append(hit[0])
        self.tv, self.members = self._triple_orbits()
        self.Q = len(self.members)
        self.e = self.tv[self.dg[IDENTITY_CLASS]]

    # -- helpers -----------------------------------------------------------

    def _triple16(self, z, mask):
        """n(x,z,w) for every w selected by `mask`."""
        common = self.V[(self.W @ self.x == CONFLICT_DOT) & (self.W @ z == CONFLICT_DOT)]
        return ((self.V[mask].astype(np.int32) @ common.astype(np.int32).T)
                == CONFLICT_DOT).sum(axis=1)

    def _labels(self, z, ci):
        """The orbital of the triple (x, z, w), for every w."""
        cz = np.searchsorted(self.dots, self.W @ z)
        lab = self.cellid[ci, self.cls0, cz]
        if ci == 3:
            m = (self.cls0 == 3) & (cz == 3)
            cnt = self._triple16(z, m)
            vals, cts = np.unique(cnt, return_counts=True)
            need(len(vals) == 2 and sorted(int(t) for t in cts) == [924, 42240],
                 "the (3,3,3) split is not 924 + 42240 for this base pair")
            small = int(vals[int(np.argmin(cts))])
            lab[m] = np.where(cnt == small, self.split_small, self.split_big)
        need(int(lab.min()) >= 0, "an unlabelled triple appeared")
        return lab

    def _triple_orbits(self):
        D = self.D
        parent = list(range(D))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        for u in range(D):
            for w in (int(self.otr[u]), int(self.osw[u])):
                a, b = find(u), find(w)
                if a != b:
                    parent[max(a, b)] = min(a, b)
        roots = sorted({find(u) for u in range(D)})
        idx = dict((r, q) for q, r in enumerate(roots))
        tv = [idx[find(u)] for u in range(D)]
        members = [[] for _ in roots]
        for u in range(D):
            members[tv[u]].append(u)
        return tv, members

    # -- exact algebra checks ---------------------------------------------

    def check_algebra(self, log, associativity=True):
        c, D = self.c, self.D
        I, J = self.oi, self.oj
        T = self.otr
        size = np.array([int(s) for s in self.size], dtype=np.int64)
        osize = self.osize
        need(not np.any(c < 0), "negative structure constant")
        supp = ((I[:, None, None] == I[None, :, None])
                & (J[:, None, None] == J[None, None, :])
                & (J[None, :, None] == I[None, None, :]))
        need(not np.any((c != 0) & ~supp), "a structure constant lies outside its support")
        rows = c.sum(axis=2)
        need(np.array_equal(rows, np.where(I[:, None] == I[None, :], osize[None, :], 0)),
             "row sums of c are wrong")
        cols = c.sum(axis=1)
        v = np.array(self.valencies, dtype=np.int64)
        need(np.array_equal(cols, np.where(J[:, None] == J[None, :],
                                           (size // v[J])[None, :], 0)),
             "column sums of c are wrong")
        lhs = size[:, None, None] * c
        rhs = np.transpose(size[:, None, None] * c[:, :, T], (1, 0, 2))
        need(np.array_equal(lhs, rhs), "|u| c^u_st != |s| c^s_{u t^T}")
        dg = self.dg
        need(np.array_equal(c[:, dg, :].sum(axis=1), np.eye(D, dtype=np.int64))
             and np.array_equal(c[:, :, dg].sum(axis=2), np.eye(D, dtype=np.int64)),
             "the 7 diagonal orbitals do not sum to the unit of the algebra")
        msg = ("    exact checks on c: support, row and column sums, "
               "|u|c^u_st = |s|c^s_{ut^T}, unit")
        if associativity:
            need(int(c.max()) ** 2 * D < 2 ** 53, "structure constants too large")
            cf = c.astype(np.float64)
            cflat = cf.reshape(D, D * D)
            cT = np.ascontiguousarray(np.transpose(cf, (0, 2, 1))).reshape(D * D, D)
            for s in range(D):
                cs = np.ascontiguousarray(cf[:, s, :])
                left = (cs @ cflat).reshape(D, D, D)
                right = np.transpose((cT @ cs).reshape(D, D, D), (0, 2, 1))
                need(np.array_equal(left, right),
                     "the structure constants are not associative (s = %d)" % s)
            msg += ", associativity"
        log(msg + ": OK")
        log("    -> the 148 labels are the orbitals and span a matrix *-algebra")


def check_certificate(sch, doc, log):
    """Recompute the three-point bound from the certificate's own data in exact
    rational arithmetic, using coefficient matrices built from the recomputed
    structure constants."""
    D, Q = sch.D, len(doc["orbit_members"])
    need(int(doc["D"]) == D, "certificate was made for D = %s" % doc["D"])
    need(int(doc["N"]) == sch.N, "certificate was made for N = %s" % doc["N"])
    need(int(doc["vars"]) == Q, "vars field disagrees with orbit_members")

    members = [[int(u) for u in ms] for ms in doc["orbit_members"]]
    need(sorted(sorted(m) for m in members) == sorted(sorted(m) for m in sch.members),
         "orbit_members is not the partition of the orbitals into unordered-triple orbits")
    tv = [-1] * D
    for q, ms in enumerate(members):
        for u in ms:
            need(tv[u] == -1, "orbit_members lists orbital %d twice" % u)
            tv[u] = q
    need(min(tv) >= 0, "orbit_members does not cover all 148 orbitals")

    kk = [int(x) for x in sch.ok]
    ii = [int(x) for x in sch.oi]
    jj = [int(x) for x in sch.oj]
    dg = sch.dg

    Cy = np.array(doc["Cy"], dtype=np.int64)
    need(Cy.shape == (D, Q), "Cy has shape %r" % (Cy.shape,))
    Cy2 = np.zeros((D, Q), dtype=np.int64)
    for u in range(D):
        Cy2[u, tv[dg[kk[u]]]] += 1
        Cy2[u, tv[u]] -= 1
    need(np.array_equal(Cy, Cy2), "Cy does not match the recomputed scheme")

    obj = np.zeros(Q, dtype=np.int64)
    for k in range(NCLASS):
        obj[tv[dg[k]]] += sch.valencies[k]
    need([int(t) for t in obj] == [int(t) for t in doc["objective"]],
         "the objective vector does not match the recomputed valencies")

    forb = [int(f) for f in doc["forbidden_classes"]]
    need([DOTS[f] for f in forb] == [int(d) for d in doc["forbidden_dots"]],
         "forbidden_classes and forbidden_dots disagree")
    need(forb == [CONFLICT_CLASS] and [int(d) for d in doc["forbidden_dots"]] == [CONFLICT_DOT],
         "this verifier only certifies the bound for the forbidden inner product 16")
    bad = set()
    for u in range(D):
        if ii[u] in forb or jj[u] in forb or kk[u] in forb:
            bad.add(tv[u])
    free = sorted(set(range(Q)) - bad)
    need(free == [int(q) for q in doc["free_orbits"]],
         "the free-variable list does not match the forbidden class")
    e = int(doc["e"])
    need(e == sch.e, "the index of the identity variable is wrong")

    log("    certificate structure: N = %d, D = %d orbitals, %d unordered-triple"
        % (sch.N, D, Q))
    log("      variables, forbidden inner product %d (60 degrees), %d free variables"
        % (CONFLICT_DOT, len(free)))

    # coefficient matrices, exact integers
    Lo = np.transpose(sch.c, (1, 0, 2)).astype(object)
    sw = np.array([int(s) for s in sch.size], dtype=object)[:, None]
    G = [sw * Lo[ms].sum(axis=0) for ms in members]
    Gy = []
    for q in range(Q):
        acc = np.zeros((D, D), dtype=object)
        for u in range(D):
            if Cy[u, q]:
                acc = acc + int(Cy[u, q]) * Lo[u]
        Gy.append(sw * acc)
    for q in range(Q):
        need(np.array_equal(G[q], G[q].T) and np.array_equal(Gy[q], Gy[q].T),
             "coefficient matrix %d is not symmetric" % q)

    a = [Fraction(0)] * Q
    for blk, Gs, tag in zip(doc["blocks"], (G, Gy), ("Y1", "Y2")):
        den = int(blk["den_exp"])
        Yint = np.zeros((D, D), dtype=object)
        for term in blk["terms"]:
            m = int(term["m"])
            need(m >= 0, "%s: negative weight -- not a PSD multiplier" % tag)
            p = np.array([int(t) for t in term["p"]], dtype=object)
            need(len(p) == D, "%s: a rank-one term has the wrong length" % tag)
            Yint = Yint + m * np.outer(p, p)
        for q in range(Q):
            a[q] += Fraction(int((Yint * Gs[q]).sum()), 1 << den)
    log("    the two PSD multipliers are given as sums of %d and %d rank-one terms"
        % (len(doc["blocks"][0]["terms"]), len(doc["blocks"][1]["terms"])))
    log("      m_i * p_i p_i^T / 2^e with m_i >= 0 and p_i integral, so they are")
    log("      positive semidefinite by construction -- no numerical PSD test is used")

    mu = [Fraction(int(n), int(d)) for n, d in doc["mu"]]
    rho = [Fraction(int(n), int(d)) for n, d in doc["rho"]]
    need(len(mu) == D and len(rho) == Q, "mu / rho have the wrong length")
    need(all(t >= 0 for t in mu) and all(t >= 0 for t in rho),
         "a negative multiplier -- the certificate is not valid")

    h = []
    for q in range(Q):
        val = Fraction(int(obj[q])) + a[q] - rho[q]
        val += sum(mu[u] * int(Cy[u, q]) for u in range(D) if Cy[u, q])
        h.append(val)
    stored = [Fraction(int(n), int(d)) for n, d in doc["h"]]
    need(h == stored, "the recomputed h differs from the stored h")

    bound = h[e] + sum(rho[q] for q in free) \
        + sum(h[q] for q in free if q != e and h[q] > 0)
    need(bound == Fraction(int(doc["bound"][0]), int(doc["bound"][1])),
         "the recomputed bound differs from the stored bound")
    floor = int(math.floor(bound))
    need(floor == int(doc["bound_floor"]), "the stored bound_floor is not the floor")

    log("    exact rational recomputation of h_q = obj_q + <Y1,G_q> + <Y2,Gy_q>")
    log("      + (mu^T Cy)_q - rho_q for all %d variables: matches the stored h" % Q)
    log("    bound = h_e + sum_{q free} rho_q + sum_{q free, q != e} max(0, h_q)")
    log("          = %s / %s" % (bound.numerator, bound.denominator))
    log("          = %.10f" % float(bound))
    log("    floor of the bound = %d   ->   every 60-degree-free set of Leech" % floor)
    log("      minimal vectors has at most %d elements" % floor)
    return {"bound": bound, "floor": floor, "Q": Q, "free": len(free)}


# --------------------------------------------------------------------------
# driver
# --------------------------------------------------------------------------

def default_sets():
    out = []
    p = os.path.join(HERE, "S496.txt")
    if os.path.exists(p):
        out.append(p)
    for i in range(64):
        p = os.path.join(HERE, "plateau", "S_%02d.txt" % i)
        if os.path.exists(p):
            out.append(p)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Verify the 496-point sets and the |S| <= 837 certificate.")
    ap.add_argument("--all", action="store_true",
                    help="run every check over every file shipped in this archive")
    ap.add_argument("--lattice", action="store_true",
                    help="only regenerate and check the Golay code and the Leech vectors")
    ap.add_argument("--set", action="append", default=[], metavar="FILE",
                    help="check this set file (may be repeated)")
    ap.add_argument("--certificate", metavar="FILE", nargs="?", const="",
                    help="re-verify this dual certificate")
    ap.add_argument("--no-maximality", action="store_true",
                    help="skip the 196560-vertex maximality sweep")
    ap.add_argument("--no-associativity", action="store_true",
                    help="skip the associativity check of the 148-dimensional algebra")
    args = ap.parse_args(argv)

    if not (args.all or args.lattice or args.set or args.certificate is not None):
        ap.print_help()
        return 2

    t0 = time.time()
    lines = []

    def log(s=""):
        print(s)
        sys.stdout.flush()
        lines.append(s)

    sets = list(args.set)
    cert = args.certificate
    if args.all:
        sets = sets + default_sets()
        if not cert:
            cert = os.path.join(HERE, "sdp3_certificate.json")
    if cert == "":
        cert = os.path.join(HERE, "sdp3_certificate.json")

    log("=" * 78)
    log("verify.py -- Leech minimal vectors, 496-point 60-degree-free sets,")
    log("             and the exact dual certificate of |S| <= 837")
    log("=" * 78)
    log("python %s, numpy %s" % (sys.version.split()[0], np.__version__))
    log("")

    log("[1] regenerating the extended binary Golay code and the Leech minimal vectors")
    t = time.time()
    words = golay_codewords()
    check_golay(words, log)
    V = leech_minimal_vectors(words)
    index, cls0 = check_lattice(V, log)
    log("  (%.1f s)" % (time.time() - t))
    log("")

    summary = {"sets": 0, "n_all_496": True, "free_total": 0, "min_tight": None,
               "antipodal_all": True, "gram": set(), "spectra": set(),
               "fingerprints": set(), "cert_floor": None}

    for path in sets:
        name = os.path.relpath(path, HERE)
        log("[2] set file: %s" % name)
        log("    sha256 %s" % sha256_file(path))
        t = time.time()
        S = read_set(path)
        r = check_set(V, index, S, name, log)
        summary["sets"] += 1
        summary["n_all_496"] = summary["n_all_496"] and r["n"] == 496
        summary["antipodal_all"] = summary["antipodal_all"] and r["antipodal"]
        summary["gram"].add(tuple(sorted(r["gram"].items())))
        summary["fingerprints"].add(r["fingerprint"])
        if not args.no_maximality:
            m = check_maximality(V, S, r["idx"], name, log, verbose=True)
            summary["free_total"] += m["free"]
            summary["min_tight"] = (m["min_tightness"] if summary["min_tight"] is None
                                    else min(summary["min_tight"], m["min_tightness"]))
            summary["spectra"].add(tuple(sorted(m["hist"].items())))
        log("  (%.1f s)" % (time.time() - t))
        log("")

    if summary["sets"] > 1:
        log("[2b] the %d set files contain %d distinct sets (two files describe the"
            % (summary["sets"], len(summary["fingerprints"])))
        log("     same set exactly when their fingerprints above agree)")
        log("")

    if cert:
        log("[3] dual certificate: %s" % os.path.relpath(cert, HERE))
        log("    sha256 %s" % sha256_file(cert))
        mp = os.path.join(HERE, "scheme_orbitals.json")
        need(os.path.exists(mp), "scheme_orbitals.json is missing from this directory")
        log("    orbital numbering: scheme_orbitals.json")
        log("    sha256 %s" % sha256_file(mp))
        t = time.time()
        with open(mp) as f:
            omap = json.load(f)
        sch = Scheme(V, cls0, omap, log)
        sch.check_algebra(log, associativity=not args.no_associativity)
        with open(cert) as f:
            doc = json.load(f)
        cr = check_certificate(sch, doc, log)
        summary["cert_floor"] = cr["floor"]
        log("  (%.1f s)" % (time.time() - t))
        log("")

    parts = ["RESULT ok=1",
             "golay_words=4096",
             "leech_vectors=%d" % V.shape[0],
             "sets_checked=%d" % summary["sets"]]
    if summary["sets"]:
        parts.append("all_size_496=%d" % int(summary["n_all_496"]))
        parts.append("all_60deg_free=1")
        parts.append("all_antipodal=%d" % int(summary["antipodal_all"]))
        parts.append("distinct_sets=%d" % len(summary["fingerprints"]))
        parts.append("distinct_gram_histograms=%d" % len(summary["gram"]))
        if not args.no_maximality:
            parts.append("free_vertices_total=%d" % summary["free_total"])
            parts.append("all_maximal=%d" % int(summary["free_total"] == 0))
            parts.append("min_tightness=%d" % summary["min_tight"])
            parts.append("distinct_tightness_spectra=%d" % len(summary["spectra"]))
    if summary["cert_floor"] is not None:
        parts.append("certificate_bound_floor=%d" % summary["cert_floor"])
    parts.append("elapsed_s=%.1f" % (time.time() - t0))
    log(" ".join(parts))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except CheckError as exc:
        sys.stderr.write("\nFAILED: %s\n" % exc)
        sys.stdout.write("\nRESULT ok=0 failure=%r\n" % str(exc))
        sys.exit(1)
